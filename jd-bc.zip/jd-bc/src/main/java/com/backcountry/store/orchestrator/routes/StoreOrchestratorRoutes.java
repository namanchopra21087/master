package com.backcountry.store.orchestrator.routes;

import org.apache.camel.builder.RouteBuilder;

public class StoreOrchestratorRoutes extends RouteBuilder {

    @Override
    public void configure() throws Exception {

    }
}
